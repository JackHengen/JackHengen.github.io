﻿using System.Text;
using WordleLibrary;

Console.OutputEncoding = Encoding.UTF8;
Console.WriteLine("Wordle!!!!!");
while (true)
{
    Game game = new Game();
    Console.WriteLine("----------------- New Game -----------------");
    while (true)
    {
        Console.Write($"Guess {game.Guesses +1}:  |  ");
        string guess = Console.ReadLine();
        Console.CursorTop--;
        Console.CursorLeft = guess.Length +13;

        if(guess.Length != 5)
        {
            Console.WriteLine("   |   That guess wasn't 5 characters long");
            
        }
        else
        {
            Console.Write($"  |  {game.Guess(guess)}  |  ");
            Console.WriteLine();
        }
        if(game.GameLost || game.GameLost)
        {
            Console.WriteLine();
        }
        if(game.GameWon)
        {
            Console.WriteLine("Good Job! You Won!");
            break;
        }
        else if(game.GameLost)
        {
            Console.WriteLine($"Oof! You lost! The word was {game.Answer}!");
            break;
        }
    }
    
}