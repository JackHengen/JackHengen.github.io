﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordleLibrary
{
    public static class StandardMessages
    {
        public static string WrongEmoji()
        {
            return "❌";
        }
        public static string CorrectEmoji()
        {
            return "✅";
        }
        public static string WrongPlaceEmoji()
        {
            return "⚠️";
        }
        public static string SpaceElementsOnLine()
        {
            return "  |  ";
        }
        public static string HorizontalLine()
        {
            return "--------------------------------------------";
        }
    }
}
