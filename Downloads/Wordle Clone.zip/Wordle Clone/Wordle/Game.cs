﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordleLibrary
{
    /// <summary>
    /// Instance of a wordle game
    /// </summary>
    public class Game
    {
        List<String> guesses = new List<string>();
        public string Answer { get; }
        public bool GameWon
        { 
            get 
            { 
                foreach(string guess in guesses)
                {
                    if(guess == Answer)
                    {
                        return true;
                    }
                    
                }
                return false;
            }
        }
        public bool GameLost
        {
            get
            {
                if(guesses.Count() == 6 && !GameWon)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public int Guesses
        {
            get
            {
                return guesses.Count();
            }
        }



        public Game()
        {
            Answer = new WordGenerator().GenerateRandom();
        }
        



        public string Guess(string guess)
        {
            guesses.Add(guess);
            return ParseGuess(guess);
        }
        
        private string ParseGuess(string guess)
        {
            string output = "";
            for(int i = 0;i<5;i++)
            {
                string tempOut = "";
                for (int j=0; j<5;j++)
                {
                    
                    if (guess[i] == Answer[i])
                    {
                        tempOut += StandardMessages.CorrectEmoji();
                        break;
                    }
                    else if (guess[i] == Answer[j])
                    {
                        tempOut += StandardMessages.WrongPlaceEmoji();
                        break;
                    }
                }
                if(tempOut == "")
                {
                    output += StandardMessages.WrongEmoji();
                }
                output += tempOut;
                
            }
            return output;
        }
    }
}
