﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordleLibrary
{
    /// <summary>
    /// information regarding user data, games won etc
    /// </summary>
    public class User
    {
        int wins;
        public void AddWin()
        {

        }
    }
}
