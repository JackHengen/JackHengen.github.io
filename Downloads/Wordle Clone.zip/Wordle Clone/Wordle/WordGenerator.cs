﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordleLibrary
{
    public class WordGenerator
    {
        string path = "WordList.txt";
        List<string> words = new List<string>();
        public WordGenerator()
        {
            LoadWords();
        }



        void LoadWords()
        {
            StreamReader sr =File.OpenText(path);
            while(!sr.EndOfStream)
            {
                words.Add(sr.ReadLine());
            }
        }



        public string GenerateRandom()
        {
            int rand =new Random().Next(words.Count);
            return words[rand];

        }
    }
}
